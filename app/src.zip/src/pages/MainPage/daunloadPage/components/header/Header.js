import React from 'react'
import classes from './../../style/header.module.css'
function Header() {
  return (
    <div className={classes.main}>
      
    </div>
  )
}

export default Header
