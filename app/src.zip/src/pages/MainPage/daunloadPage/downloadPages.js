import React from 'react';
import Mobile from "./components/mobile/Mobile";

const DownloadPages = () => {
    return (
        <div>
            <Mobile/>
        </div>
    );
};

export default DownloadPages;