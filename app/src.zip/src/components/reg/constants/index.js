export * from "./error-message";
export * from "./regex";

export const MIN_PASSWORD_LENGTH = 3;
export const MAX_PASSWORD_LENGTH = 9;
