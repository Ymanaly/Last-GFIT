export const SIMILAR_ERROR_MESSAGE = "Пароли должны совпадать";
